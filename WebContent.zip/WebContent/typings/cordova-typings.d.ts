
/// <reference path="..\.vscode\typings\cordova\cordova.d.ts"/>